#!/bin/sh

PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

INSTALLED_PREFIX="Installed: "
CANDIDATE_PREFIX="Candidate: "

apt-get update -y
INSTALLED_VERSION=`apt-cache policy fr24feed | grep "$INSTALLED_PREFIX" | sed "s/[[:blank:]]*$INSTALLED_PREFIX[[:blank:]]*//"`
CANDIDATE_VERSION=`apt-cache policy fr24feed | grep "$CANDIDATE_PREFIX" | sed "s/[[:blank:]]*$CANDIDATE_PREFIX[[:blank:]]*//"`

echo "Installed version: $INSTALLED_VERSION"
echo "Latest available: $CANDIDATE_VERSION"

if [ "$INSTALLED_VERSION" != "$CANDIDATE_VERSION" ]
then
  echo "Upgrading fr24feed..."
  echo "Waiting for fr24feed to stop completely..."
  service fr24feed stop
  sleep 30

  PID=`pidof fr24feed`
  if [ ! -z "$PID" ]
  then
    pkill -9 -P $PID
    kill -9 $PID
  fi

  apt-get install -y fr24feed || echo "Failed to update, restarting current version..."
  service fr24feed restart
else
  echo "Latest version is already installed"
fi

